#include <iostream>
#include <string>
#include "GeneralPlayer.h"

using namespace std;

class GeneralPlayer;
class SelectList
{
public:
	SelectList();
	void select(GeneralPlayer*);
};