#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "GeneralPlayer.h"
#include "KnightPlayer.h"
#include "MagicianPlayer.h"
#include "OrcPlayer.h"
#include "AbstractMonster.h"
#include "GoblinMonster.h"
#include "Battle.h"
#include "Field.h"
#include "Item.h"
#include "WeaponItem.h"
#include "ArmorItem.h"
#include "ConsumableItem.h"
#include "SelectList.h"

using namespace std;

int main()
{
	bool gameover = false;
	cout << "Welcome to this GAME" << endl;
	cout << "---Select Action---" << endl
		<< "1. Start New Game" << endl
		<< "2. Continue the Last Game" << endl << "-";
	int action;
	cin >> action;
	system("CLS");

	GeneralPlayer **Players = new GeneralPlayer*[1];
	Players[0] = new GeneralPlayer;
	switch (action)
	{
	case 1:
		cout << "Welcome to the Start Villige" << endl << endl
			<< "You are going to start an adventure and to find the treasure from JWMonster" << endl << endl;
		system("PAUSE");
		cout << endl << "Now choose your career" << endl
			<< "There are 4 kinds of jobs:" << endl
			<< "1. General People" << endl
			<< "2. Knight" << endl
			<< "3. Magician" << endl
			<< "4. Orc" << endl << "-";
		int job;
		cin >> job;
		enum job{General = 1, Knight, Magician, Orc};
		if (job == General)
		{
			GeneralPlayer General(1);
			cout << "Input your name: ";
			string namePlayer;
			cin >> namePlayer;
			General.setName(namePlayer);
			system("CLS");
			cout << "---Player's Information---" << endl
				<< "Name: " << General.getName() << endl
				<< "Level: " << General.getLevel() << endl
				<< "HP: " << General.getHP() << "/" << General.getMaxHP() << endl
				<< "MP: " << General.getMP() << "/" << General.getMaxMP() << endl
				<< "Exp: " << General.getExp() << endl
				<< "Attack: " << General.getAttack() << endl
				<< "Defense: " << General.getDefense() << endl
				<< "Money: " << General.getMoney() << endl << endl;
			//GeneralPlayer *Players = new  GeneralPlayer[1];
			Players[0] = &General;
		}
		else if (job == Knight)
		{
			KnightPlayer Knight(1);
			cout << "Input your name: ";
			string namePlayer;
			cin >> namePlayer;
			Knight.setName(namePlayer);
			system("CLS");
			cout << "---Player's Information---" << endl
				<< "Name: " << Knight.getName() << endl
				<< "Level: " << Knight.getLevel() << endl
				<< "HP: " << Knight.getHP() << "/" << Knight.getMaxHP() << endl
				<< "MP: " << Knight.getMP() << "/" << Knight.getMaxMP() << endl
				<< "Exp: " << Knight.getExp() << endl
				<< "Attack: " << Knight.getAttack() << endl
				<< "Defense: " << Knight.getDefense() << endl
				<< "Money: " << Knight.getMoney() << endl << endl;
			//GeneralPlayer *Players = new  GeneralPlayer[1];
			Players[0] = &Knight;
		}
		else if (job == Magician)
		{
			MagicianPlayer Magician;
			cout << "Input your name: ";
			string namePlayer;
			cin >> namePlayer;
			Magician.setName(namePlayer);
			system("CLS");
			cout << "---Player's Information---" << endl
				<< "Name: " << Magician.getName() << endl
				<< "Level: " << Magician.getLevel() << endl
				<< "HP: " << Magician.getHP() << "/" << Magician.getMaxHP() << endl
				<< "MP: " << Magician.getMP() << "/" << Magician.getMaxMP() << endl
				<< "Exp: " << Magician.getExp() << endl
				<< "Attack: " << Magician.getAttack() << endl
				<< "Defense: " << Magician.getDefense() << endl
				<< "Money: " << Magician.getMoney() << endl << endl;
			//GeneralPlayer *Players = new  GeneralPlayer[1];
			Players[0] = &Magician;
		}
		else if (job == Orc)
		{
			OrcPlayer Orc;
			cout << "Input your name: ";
			string namePlayer;
			cin >> namePlayer;
			Orc.setName(namePlayer);
			system("CLS");
			cout << "---Player's Information---" << endl
				<< "Name: " << Orc.getName() << endl
				<< "Level: " << Orc.getLevel() << endl
				<< "HP: " << Orc.getHP() << "/" << Orc.getMaxHP() << endl
				<< "MP: " << Orc.getMP() << "/" << Orc.getMaxMP() << endl
				<< "Exp: " << Orc.getExp() << endl
				<< "Attack: " << Orc.getAttack() << endl
				<< "Defense: " << Orc.getDefense() << endl
				<< "Money: " << Orc.getMoney() << endl << endl;
			//GeneralPlayer *Players = new GeneralPlayer[1];
			Players[0] = &Orc;
		}
	}
	GoblinMonster Monster1("Monster", 100, 100, 100, 100, 100, 100);
	GoblinMonster *Monsters = new GoblinMonster[1];
	Monsters[0] = Monster1;

	//WeaponItem Knife(1, "Knife", "increase attack by 50", "a weapon", 50, 'w', 50);
	//ArmorItem Shield(1, "Shield", "increase defense 100","an armor ",100, 'a', 100);

	//level-required, name, effects, description, weight, type, attack-increment
	SelectList Select;
	Select.select(Players[0]);
	
	cout << "BATTLE first!!!" << endl;
	//Battle Battle1(Players[0], Monsters, 1, 1, 3);
	
	return 0;
}