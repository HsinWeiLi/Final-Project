#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "Field.h"

using namespace std;

Field::Field(int**map_input, int length, int width, int X, int Y, int vision_width_input, int vision_height_input)
{
	map_data = new int*[length];
	for (int j = 0; j < length; j++)
		map_data[j] = new int [width];
	for (int j = 0; j < length; j++)
		for (int i = 0; i < width; i++)
			map_data[j][i] = map_input[j][i];

	setPosition(X, Y);
	setVisionSize(vision_width_input, vision_height_input);
	map_length = length;
	map_width = width;
}
Field::Field(const char* file_name, int X, int Y, int vision_width_input, int vision_height_input)
{
	int width, length;
	ifstream data(file_name, ios::in);
	if (!data)
	{
		cerr << "File could not be opened" << endl;
		exit(1);
	}
	string info;
	getline(data, info);
	istringstream input(info);
	input >> width;
	input.get();
	input >> length;

	map_data = new int*[length];
	for (int j = 0; j < length; j++)
		map_data[j] = new int[width];

	int column = 0;
	int row;
	while (getline(data, info))
	{
		row = 0;
		for (int i = 0; i < info.length(); i++)
		{
			if (info[i] != ',')
			{
				int s;
				istringstream get(&info[i]);
				get >> s;
				if (s >= 10 && s < 100)
					i++;
				else if (s >= 100)
					i += 2;
				map_data[column][row] = s;
				row++;
			}
		}
		column++;
	}
	setPosition(X, Y);
	setVisionSize(vision_width_input, vision_height_input);
	map_length = length;
	map_width = width;
}
bool Field::move(char direction)
{
	if (direction == 'U')
	{
		if (moveUp() == false)
			return false;
		else
			return true;
	}
	else if (direction == 'D')
	{
		if (moveDown() == false)
			return false;
		else
			return true;
	}
	else if (direction == 'R')
	{
		if (moveRight() == false)
			return false;
		else
			return true;
	}
	else if (direction == 'L')
	{
		if (moveLeft() == false)
			return false;
		else
			return true;
	}
	else
		return false;
}
bool Field::moveUp(void)
{
	if (map_data[current_position_y - 1][current_position_x] != 1)
	{
		current_position_y--;
		return true;
	}
	else return false;
}
bool Field::moveDown(void)
{
	if (map_data[current_position_y + 1][current_position_x] != 1)
	{
		current_position_y++;
		return true;
	}
	else return false;
}
bool Field::moveRight(void)
{
	if (map_data[current_position_y][current_position_x + 1] != 1)
	{
		current_position_x++;
		return true;
	}
	else return false;
}
bool Field::moveLeft(void)
{
	if (map_data[current_position_y][current_position_x - 1] != 1)
	{
		current_position_x--;
		return true;
	}
	else return false;
}
int Field::getCurrentPosition_x(void) const
{
	return current_position_x;
}
int Field::getCurrentPosition_y(void) const
{
	return current_position_y;
}
int Field::getVisionWidth(void) const
{
	return vision_width;
}
int Field::getVisionHeight(void) const
{
	return vision_hieght;
}
string Field::getMapName(void) const
{
	return map_name;
}
int Field::getMapSymbol(int x_input, int y_input)
{
	return map_data[y_input][x_input];
}
void Field::setPosition(int x_input, int y_input)
{
	current_position_x = x_input;
	current_position_y = y_input;
}
void Field::setMapSymbol(int symbol_input, int x_input, int y_input)
{
	map_data[y_input][x_input] = symbol_input;
}
void Field::setVisionSize(int width_input, int height_input)
{
	vision_width = width_input;
	vision_hieght = height_input;
}
void Field::display(void) const
{
	for (int j = 0; j < map_length; j++)
	{
		for (int i = 0; i < map_width; i++)
		{
			if (map_data[j][i] == 1) //wall
				cout << "��";
			else if (map_data[j][i] == 2) //pace
				cout << " X";
			else if (map_data[j][i] == 200) //start
				cout << " S";
			else if (map_data[j][i] == 201) //destination
				cout << " D";
			else if (map_data[j][i] >= 202 || map_data[j][i] == 9) //bonus
				cout << "��";
			else if (map_data[j][i] == 0) //the pace not taken
				cout << "  ";
		}
		cout << endl;
	}
}
int Field::getMapLength(void) const
{
	return map_length;
}
int Field::getMapWidth(void) const
{
	return map_width;
}